<?php
// Patikriname, ar formos duomenys gauti
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Gauti įvestą skaičių N
    $N = intval($_POST['number']);

    if ($N < 2) {
        echo "Skaičius turi būti didesnis arba lygus 2.";
        exit;
    }

    // Skaičiuoti kvadratų sumą
    $sum = 0;
    for ($i = 2; $i <= $N; $i++) {
        $sum += $i * $i;
    }

    // Duomenų bazės nustatymai
    $servername = "localhost";
    $username = "root";  // Numatytoji phpMyAdmin vartotojo paskyra
    $password = "";      // Numatytoji phpMyAdmin slaptažodžio reikšmė
    $dbname = "test_db"; // Duomenų bazės pavadinimas

    // Sukuriame ryšį su duomenų baze
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Patikriname, ar nėra klaidų prisijungiant
    if ($conn->connect_error) {
        die("Nepavyko prisijungti prie duomenų bazės: " . $conn->connect_error);
    }

    // Įrašome rezultatą į duomenų bazę
    $sql = "INSERT INTO results (number, square_sum) VALUES ('$N', '$sum')";

    if ($conn->query($sql) === TRUE) {
        echo "Rezultatas sėkmingai įrašytas į duomenų bazę.<br>";
    } else {
        echo "Klaida įrašant į duomenų bazę: " . $conn->error;
    }

    // Išvedame kvadratų sumą ekrane
    echo "Skaičių nuo 2 iki $N kvadratų suma yra: $sum";

    // Užbaigiame ryšį su duomenų baze
    $conn->close();
}
?>
